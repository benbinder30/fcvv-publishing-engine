# FCVV Publishing Engine — Milestone 3

Milestone 3 improves the visual system and begins replacing prototype placeholders with linked SVG assets.

## What's new

- Improved cover
- Running page footer and page numbers
- Cleaner reusable panels
- Linked SVG pitch placement
- SVG icon support foundations
- Improved Week 1 overview
- Improved practice spread layout
- Safer global namespace

## How to run

1. Open Adobe InDesign.
2. File > Scripts > Other Script...
3. Select `src/main.jsx`
4. Choose the top-level `fcvv-publishing-engine-milestone-3` folder.
5. Outputs are saved to `/exports`.

## Output

- `FCVV_Handbook_Milestone3.indd`
- `FCVV_Handbook_Milestone3.pdf`
