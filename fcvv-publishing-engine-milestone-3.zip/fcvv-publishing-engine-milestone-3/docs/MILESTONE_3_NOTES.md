# Milestone 3 Notes

This milestone focuses on visual quality and reusable layout components.

The engine now places linked SVGs from the project folder, so future diagram assets can be dropped into `/assets/svg/` and referenced from JSON.
