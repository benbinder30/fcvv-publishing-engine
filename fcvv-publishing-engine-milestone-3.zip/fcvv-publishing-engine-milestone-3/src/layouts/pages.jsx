$.global.FCVV = $.global.FCVV || {};
var FCVV = $.global.FCVV;

FCVV.addFooter = function(page, label){
    FCVV.addBox(page,0,198,297,5,"FCVV Red","FCVV Red");
    FCVV.addText(page,15,190,120,5,"FC Viking & Valkyries | Official Coaching Handbook","Footer");
    FCVV.addText(page,210,190,70,5,label || "Volume 1","Footer");
};

FCVV.addPageNumbers = function(doc){
    for(var i=0;i<doc.pages.length;i++){
        var p = doc.pages[i];
        FCVV.addText(p,282,190,10,5,String(i+1),"Footer");
    }
};

FCVV.buildCover = function(doc,publication){
    var p = doc.pages[0];
    FCVV.addBox(p,0,0,297,210,"Midnight Black","Midnight Black");
    FCVV.addBox(p,0,0,18,210,"FCVV Red","FCVV Red");
    FCVV.addBox(p,0,176,297,12,"FCVV Red","FCVV Red");
    FCVV.addText(p,32,42,240,18,publication.title,"H1_Cover");
    FCVV.addText(p,32,70,240,14,publication.subtitle,"H1_Cover");
    FCVV.addText(p,32,100,240,15,publication.volume,"Quote");
    FCVV.addText(p,32,150,240,12,publication.tagline,"Quote");
};

FCVV.buildContents = function(doc){
    var p = doc.pages.add();
    FCVV.addText(p,18,18,260,12,"Contents","H1_Week");
    FCVV.addBox(p,18,35,250,1,"FCVV Red","FCVV Red");
    FCVV.addText(p,20,50,250,100,"1. How to Use This Handbook\r2. FCVV Coaching DNA\r3. Week 1 - Reconnect & Rebuild\r4. Performance Cards\r5. Coach Resources","Body");
    FCVV.addFooter(p,"Contents");
};

FCVV.buildFrontMatter = function(doc,frontMatter){
    for(var i=0;i<frontMatter.length;i++){
        var fm=frontMatter[i], p=doc.pages.add();
        FCVV.addText(p,18,18,260,12,fm.title,"H1_Week");
        FCVV.addBox(p,18,35,250,1,"FCVV Red","FCVV Red");
        var body=""; for(var j=0;j<fm.body.length;j++) body += fm.body[j] + "\r\r";
        FCVV.addText(p,20,48,250,120,body,"Body");
        FCVV.addFooter(p,fm.title);
    }
};

FCVV.buildWeek = function(doc,week){
    var p = doc.pages.add();
    FCVV.addBox(p,0,0,297,28,"Midnight Black","Midnight Black");
    FCVV.addBox(p,0,28,297,5,"FCVV Red","FCVV Red");
    FCVV.addText(p,18,7,260,12,"Week " + week.week + " - " + week.title,"H1_Cover");
    FCVV.addText(p,20,42,250,18,week.statement,"Quote");
    FCVV.panel(p,"SESSION SNAPSHOT",FCVV.sessionSnapshotText(week.snapshot),20,68,120,82,"FCVV Red");
    var cr = "Today's Message: " + week.coachReady.message + "\r\r" + FCVV.listText("Success Looks Like", week.coachReady.successLooksLike) + "\r" + FCVV.listText("Watch For", week.coachReady.watchFor);
    FCVV.panel(p,"COACH READY",cr,155,68,120,82,"Midnight Black");
    var tl=""; for(var t=0;t<week.timeline.length;t++) tl += week.timeline[t][0] + "  " + week.timeline[t][1] + "\r";
    FCVV.panel(p,"SESSION TIMELINE",tl,20,160,255,30,"Graphite");
    FCVV.addFooter(p,"Week " + week.week);
    for(var i=0;i<week.practices.length;i++) FCVV.buildPractice(doc,week.practices[i], week.week);
};

FCVV.buildPractice = function(doc,practice,weekNo){
    var p = doc.pages.add();
    FCVV.addBox(p,0,0,297,10,"Midnight Black","Midnight Black");
    FCVV.addText(p,18,16,260,10,practice.title,"H1_Week");
    FCVV.diagram(p,practice.diagram,18,36,158,104);

    var txt = "OBJECTIVE\r" + practice.objective + "\r\rORGANISATION\r" + practice.organisation + "\r\rCOACHING POINTS\r";
    for(var cp=0;cp<practice.coachingPoints.length;cp++) txt += "- " + practice.coachingPoints[cp] + "\r";
    FCVV.addText(p,188,36,90,72,txt,"Body");

    if(practice.coachScript) FCVV.panel(p,"COACH SCRIPT",FCVV.listText("",practice.coachScript),188,116,90,30,"Coach Blue");
    FCVV.panel(p,"ON THE GRASS",practice.onTheGrass,18,150,80,34,"Performance Green");
    FCVV.panel(p,"QUICK FIX",practice.quickFix,108,150,80,34,"Warning Amber");
    FCVV.panel(p,"MATCH TRANSFER",practice.matchTransfer,198,150,80,34,"Graphite");
    FCVV.addFooter(p,"Week " + weekNo);
};
