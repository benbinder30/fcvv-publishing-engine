#target "InDesign"
(function(){
    var selected = Folder.selectDialog("Select the TOP-LEVEL fcvv-publishing-engine-milestone-3 folder");
    if(!selected) return;
    $.global.FCVV = {};
    var srcFolder = new Folder(selected.fsName + "/src");

    function loadModule(relativePath){
        var f = new File(srcFolder.fsName + "/" + relativePath);
        if(!f.exists){ alert("Missing module:\n" + f.fsName); throw new Error("Missing module: " + relativePath); }
        $.evalFile(f);
    }

    loadModule("core/utils.jsx");
    loadModule("core/json.jsx");
    loadModule("core/document.jsx");
    loadModule("core/styles.jsx");
    loadModule("core/layers.jsx");
    loadModule("core/masters.jsx");
    loadModule("builders/components.jsx");
    loadModule("layouts/pages.jsx");

    var FCVV = $.global.FCVV;
    FCVV.projectFolder = selected;

    var raw = FCVV.readText(selected.fsName + "/content/handbook.json");
    var data = FCVV.parseJSONSafe(raw);
    if(!data) return;

    var doc = FCVV.createDocument();
    FCVV.createSwatches(doc);
    FCVV.createParagraphStyles(doc);
    FCVV.createLayers(doc);
    FCVV.createMasterPages(doc);

    FCVV.buildCover(doc, data.publication);
    FCVV.buildContents(doc);
    FCVV.buildFrontMatter(doc, data.frontMatter);
    for(var i=0;i<data.weeks.length;i++) FCVV.buildWeek(doc, data.weeks[i]);

    FCVV.addPageNumbers(doc);

    var out = new Folder(selected.fsName + "/exports");
    if(!out.exists) out.create();
    doc.save(new File(out.fsName + "/FCVV_Handbook_Milestone3.indd"));
    try { doc.exportFile(ExportFormat.PDF_TYPE, new File(out.fsName + "/FCVV_Handbook_Milestone3.pdf")); } catch(e) {}
    alert("Milestone 3 complete. Files saved to exports folder.");
})();
