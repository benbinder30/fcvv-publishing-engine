$.global.FCVV = $.global.FCVV || {};
var FCVV = $.global.FCVV;
FCVV.createDocument = function(){
    var doc = app.documents.add();
    doc.documentPreferences.pageWidth = "297mm";
    doc.documentPreferences.pageHeight = "210mm";
    doc.documentPreferences.facingPages = false;
    doc.documentPreferences.documentBleedTopOffset = "3mm";
    doc.documentPreferences.documentBleedBottomOffset = "3mm";
    doc.documentPreferences.documentBleedInsideOrLeftOffset = "3mm";
    doc.documentPreferences.documentBleedOutsideOrRightOffset = "3mm";
    doc.marginPreferences.top = "15mm";
    doc.marginPreferences.bottom = "15mm";
    doc.marginPreferences.left = "15mm";
    doc.marginPreferences.right = "15mm";
    return doc;
};
