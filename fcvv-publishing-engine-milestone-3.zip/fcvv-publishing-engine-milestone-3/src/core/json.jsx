$.global.FCVV = $.global.FCVV || {};
var FCVV = $.global.FCVV;
FCVV.trimJSONText = function(t){ if(!t) return ""; if(t.charCodeAt(0) === 0xFEFF) t = t.substring(1); return t.replace(/^\s+/, "").replace(/\s+$/, ""); };
FCVV.parseJSONSafe = function(raw){ raw = FCVV.trimJSONText(raw); if(typeof JSON !== "undefined" && JSON.parse){ try{ return JSON.parse(raw); }catch(e){} } try{ return eval("(" + raw + ")"); } catch(e2){ alert("Could not parse JSON:\n" + e2); return null; } };
