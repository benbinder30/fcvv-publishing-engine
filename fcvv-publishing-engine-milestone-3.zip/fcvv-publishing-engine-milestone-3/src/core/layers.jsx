$.global.FCVV = $.global.FCVV || {};
var FCVV = $.global.FCVV;
FCVV.createLayers = function(doc){ var names=["Background","Images","Diagrams","Panels","Text","Navigation"]; for(var i=names.length-1;i>=0;i--){ try{doc.layers.itemByName(names[i]).name;} catch(e){doc.layers.add({name:names[i]});} } };
