$.global.FCVV = $.global.FCVV || {};
var FCVV = $.global.FCVV;

FCVV.projectFolder = null;

FCVV.mm = function(v){ return v + "mm"; };

FCVV.readText = function(path){
    var f = new File(path);
    if(!f.exists){ alert("Missing file:\n" + path); return null; }
    f.encoding = "UTF-8"; f.open("r"); var t = f.read(); f.close(); return t;
};

FCVV.assetFile = function(relativePath){
    if(!FCVV.projectFolder) return null;
    return new File(FCVV.projectFolder.fsName + "/" + relativePath);
};

FCVV.addText = function(page,x,y,w,h,txt,styleName){
    var tf = page.textFrames.add();
    tf.geometricBounds = [FCVV.mm(y),FCVV.mm(x),FCVV.mm(y+h),FCVV.mm(x+w)];
    tf.contents = txt || "";
    if(styleName){
        try{ tf.parentStory.paragraphs.everyItem().appliedParagraphStyle = app.activeDocument.paragraphStyles.itemByName(styleName); }catch(e){}
    }
    return tf;
};

FCVV.addBox = function(page,x,y,w,h,fillName,strokeName){
    var r = page.rectangles.add();
    r.geometricBounds = [FCVV.mm(y),FCVV.mm(x),FCVV.mm(y+h),FCVV.mm(x+w)];
    try{ r.fillColor = app.activeDocument.swatches.itemByName(fillName); }catch(e){}
    try{ r.strokeColor = app.activeDocument.swatches.itemByName(strokeName || fillName); }catch(e){}
    return r;
};

FCVV.placeSVG = function(page, relativePath, x, y, w, h){
    var f = FCVV.assetFile(relativePath);
    var frame = page.rectangles.add();
    frame.geometricBounds = [FCVV.mm(y),FCVV.mm(x),FCVV.mm(y+h),FCVV.mm(x+w)];
    try { frame.strokeColor = app.activeDocument.swatches.itemByName("Steel Grey"); } catch(e) {}
    if(f && f.exists){
        try {
            frame.place(f);
            frame.fit(FitOptions.PROPORTIONALLY);
            frame.fit(FitOptions.CENTER_CONTENT);
        } catch(e2) {
            FCVV.addText(page,x+5,y+5,w-10,10,"SVG PLACE FAILED: " + relativePath,"Small");
        }
    } else {
        try { frame.fillColor = app.activeDocument.swatches.itemByName("Steel Grey"); } catch(e3) {}
        FCVV.addText(page,x+5,y+5,w-10,10,"MISSING SVG: " + relativePath,"Small");
    }
    return frame;
};
