# FCVV Publishing Engine — Milestone 2 FIXED v2

This version fixes the `FCVV is undefined` error.

## Run

1. Open Adobe InDesign.
2. Go to `File > Scripts > Other Script...`.
3. Select `src/main.jsx`.
4. When prompted, choose the top-level folder: `fcvv-publishing-engine-milestone-2-fixed-v2`.
5. Output saves to `/exports`.

## What changed

All modules now use `$.global.FCVV`, which is safer in InDesign ExtendScript when scripts are loaded using `$.evalFile()`.
