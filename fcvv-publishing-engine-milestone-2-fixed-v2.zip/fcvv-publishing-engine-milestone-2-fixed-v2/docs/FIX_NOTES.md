This version fixes `FCVV is undefined` by storing the FCVV namespace on `$.global.FCVV` in every loaded module.
