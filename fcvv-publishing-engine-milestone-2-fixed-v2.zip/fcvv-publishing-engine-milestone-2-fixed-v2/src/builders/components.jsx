$.global.FCVV = $.global.FCVV || {};
var FCVV = $.global.FCVV;

FCVV.panel = function(page,title,body,x,y,w,h,fillName){
    FCVV.addBox(page,x,y,w,h,fillName,fillName);
    FCVV.addText(page,x+4,y+4,w-8,8,title,"Panel_Title");
    FCVV.addText(page,x+4,y+15,w-8,h-18,body,"Small");
};

FCVV.diagramPlaceholder = function(page,x,y,w,h){
    FCVV.addBox(page,x,y,w,h,"Steel Grey","Steel Grey");
    FCVV.addText(page,x+10,y+h/2-5,w-20,12,"UEFA DIAGRAM PLACEHOLDER","H2_Section");
};

FCVV.sessionSnapshotText = function(snapshot){
    var txt = "";
    for(var k in snapshot) txt += k + ": " + snapshot[k] + "\r";
    return txt;
};

FCVV.listText = function(heading,arr){
    var txt = heading ? heading + "\r" : "";
    for(var i=0;i<arr.length;i++) txt += "- " + arr[i] + "\r";
    return txt;
};
