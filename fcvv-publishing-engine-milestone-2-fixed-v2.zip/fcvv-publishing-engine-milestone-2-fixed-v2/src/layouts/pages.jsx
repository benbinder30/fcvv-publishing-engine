$.global.FCVV = $.global.FCVV || {};
var FCVV = $.global.FCVV;

FCVV.buildCover = function(doc,publication){
    var p = doc.pages[0];
    FCVV.addBox(p,0,0,297,210,"Midnight Black","Midnight Black");
    FCVV.addBox(p,0,176,297,12,"FCVV Red","FCVV Red");
    FCVV.addText(p,22,42,250,18,publication.title,"H1_Cover");
    FCVV.addText(p,22,70,250,14,publication.subtitle,"H1_Cover");
    FCVV.addText(p,22,100,250,15,publication.volume,"Quote");
    FCVV.addText(p,22,150,250,12,publication.tagline,"Quote");
};

FCVV.buildContents = function(doc){
    var p = doc.pages.add();
    FCVV.addText(p,18,18,260,12,"Contents","H1_Week");
    FCVV.addText(p,20,42,250,120,"1. How to Use This Handbook\r2. FCVV Coaching DNA\r3. Week 1 - Reconnect & Rebuild\r4. Performance Cards\r5. Coach Resources","Body");
};

FCVV.buildFrontMatter = function(doc,frontMatter){
    for(var i=0;i<frontMatter.length;i++){
        var fm=frontMatter[i], p=doc.pages.add();
        FCVV.addText(p,18,18,260,12,fm.title,"H1_Week");
        var body=""; for(var j=0;j<fm.body.length;j++) body += fm.body[j] + "\r\r";
        FCVV.addText(p,20,45,250,120,body,"Body");
    }
};

FCVV.buildWeek = function(doc,week){
    var p = doc.pages.add();
    FCVV.addBox(p,0,0,297,24,"Midnight Black","Midnight Black");
    FCVV.addText(p,18,8,260,12,"Week " + week.week + " - " + week.title,"H1_Cover");
    FCVV.addText(p,20,38,250,20,week.statement,"Quote");
    FCVV.panel(p,"SESSION SNAPSHOT",FCVV.sessionSnapshotText(week.snapshot),20,68,120,82,"FCVV Red");
    var cr = "Today's Message: " + week.coachReady.message + "\r\r";
    cr += FCVV.listText("Success Looks Like", week.coachReady.successLooksLike);
    cr += "\r" + FCVV.listText("Watch For", week.coachReady.watchFor);
    FCVV.panel(p,"COACH READY",cr,155,68,120,82,"Midnight Black");
    var tl=""; for(var t=0;t<week.timeline.length;t++) tl += week.timeline[t][0] + "  " + week.timeline[t][1] + "\r";
    FCVV.panel(p,"SESSION TIMELINE",tl,20,160,255,32,"Graphite");
    for(var i=0;i<week.practices.length;i++) FCVV.buildPractice(doc,week.practices[i]);
};

FCVV.buildPractice = function(doc,practice){
    var p = doc.pages.add();
    FCVV.addText(p,18,14,260,10,practice.title,"H1_Week");
    FCVV.diagramPlaceholder(p,18,34,160,108);
    var txt = "OBJECTIVE\r" + practice.objective + "\r\rORGANISATION\r" + practice.organisation + "\r\rCOACHING POINTS\r";
    for(var cp=0;cp<practice.coachingPoints.length;cp++) txt += "- " + practice.coachingPoints[cp] + "\r";
    FCVV.addText(p,188,34,90,105,txt,"Body");
    FCVV.panel(p,"ON THE GRASS",practice.onTheGrass,18,152,80,34,"Performance Green");
    FCVV.panel(p,"QUICK FIX",practice.quickFix,108,152,80,34,"Warning Amber");
    FCVV.panel(p,"MATCH TRANSFER",practice.matchTransfer,198,152,80,34,"Graphite");
    if(practice.coachScript) FCVV.panel(p,"COACH SCRIPT",FCVV.listText("",practice.coachScript),188,124,90,24,"Coach Blue");
};
