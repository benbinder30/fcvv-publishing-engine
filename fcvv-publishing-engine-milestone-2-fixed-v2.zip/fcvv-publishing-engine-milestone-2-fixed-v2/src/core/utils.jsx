$.global.FCVV = $.global.FCVV || {};
var FCVV = $.global.FCVV;

FCVV.mm = function(v){ return v + "mm"; };

FCVV.readText = function(path){
    var f = new File(path);
    if(!f.exists){ alert("Missing file:\n" + path); return null; }
    f.encoding = "UTF-8";
    f.open("r");
    var t = f.read();
    f.close();
    return t;
};

FCVV.addText = function(page,x,y,w,h,txt,styleName){
    var tf = page.textFrames.add();
    tf.geometricBounds = [FCVV.mm(y),FCVV.mm(x),FCVV.mm(y+h),FCVV.mm(x+w)];
    tf.contents = txt || "";
    if(styleName){
        try{ tf.parentStory.paragraphs[0].appliedParagraphStyle = app.activeDocument.paragraphStyles.itemByName(styleName); }catch(e){}
    }
    return tf;
};

FCVV.addBox = function(page,x,y,w,h,fillName,strokeName){
    var r = page.rectangles.add();
    r.geometricBounds = [FCVV.mm(y),FCVV.mm(x),FCVV.mm(y+h),FCVV.mm(x+w)];
    try{ r.fillColor = app.activeDocument.swatches.itemByName(fillName); }catch(e){}
    try{ r.strokeColor = app.activeDocument.swatches.itemByName(strokeName || fillName); }catch(e){}
    return r;
};
