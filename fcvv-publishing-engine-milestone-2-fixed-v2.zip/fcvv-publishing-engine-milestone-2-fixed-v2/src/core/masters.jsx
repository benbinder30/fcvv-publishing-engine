$.global.FCVV = $.global.FCVV || {};
var FCVV = $.global.FCVV;

FCVV.createMasterPages = function(doc){
    try{ doc.masterSpreads.item(0).namePrefix = "A"; }catch(e){}
};
