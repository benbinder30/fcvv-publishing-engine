$.global.FCVV = $.global.FCVV || {};
var FCVV = $.global.FCVV;

FCVV.makeSwatch = function(doc,name,cmyk){
    var s;
    try{ s = doc.colors.itemByName(name); s.name; }
    catch(e){ s = doc.colors.add(); s.name=name; s.model=ColorModel.PROCESS; s.space=ColorSpace.CMYK; s.colorValue=cmyk; }
    return s;
};

FCVV.createSwatches = function(doc){
    FCVV.makeSwatch(doc,"FCVV Red",[16,100,91,7]);
    FCVV.makeSwatch(doc,"Midnight Black",[0,0,0,93]);
    FCVV.makeSwatch(doc,"Arctic White",[0,0,0,0]);
    FCVV.makeSwatch(doc,"Steel Grey",[0,0,0,15]);
    FCVV.makeSwatch(doc,"Graphite",[0,0,0,60]);
    FCVV.makeSwatch(doc,"Performance Green",[63,8,100,32]);
    FCVV.makeSwatch(doc,"Warning Amber",[0,25,85,2]);
    FCVV.makeSwatch(doc,"Coach Blue",[83,54,0,0]);
};

FCVV.makeParaStyle = function(doc,name,size,swatch,style){
    var s;
    try{ s = doc.paragraphStyles.itemByName(name); s.name; }
    catch(e){ s = doc.paragraphStyles.add({name:name}); }
    s.pointSize = size;
    s.leading = size * 1.2;
    try{ s.fillColor = doc.swatches.itemByName(swatch); }catch(e){}
    if(style){ try{s.fontStyle = style;}catch(e2){} }
    return s;
};

FCVV.createParagraphStyles = function(doc){
    FCVV.makeParaStyle(doc,"H1_Cover",34,"Arctic White","Bold");
    FCVV.makeParaStyle(doc,"H1_Week",26,"FCVV Red","Bold");
    FCVV.makeParaStyle(doc,"H2_Section",18,"Midnight Black","Bold");
    FCVV.makeParaStyle(doc,"H3_Component",13,"FCVV Red","Bold");
    FCVV.makeParaStyle(doc,"Body",10.5,"Midnight Black",null);
    FCVV.makeParaStyle(doc,"Small",8,"Graphite",null);
    FCVV.makeParaStyle(doc,"Quote",14,"Graphite","Italic");
    FCVV.makeParaStyle(doc,"Panel_Title",9,"Arctic White","Bold");
};
