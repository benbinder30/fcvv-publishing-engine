# FCVV Publishing Engine — Milestone 1 FIXED

This version fixes the `JSON.parse(raw)` issue in Adobe InDesign ExtendScript.

## What changed

ExtendScript in some InDesign installs does not reliably support `JSON.parse()`.  
The build script now uses a safer `parseJSON()` helper:

1. Trims hidden BOM characters.
2. Uses `JSON.parse()` if available.
3. Falls back to `eval()` if required.

## How to run

1. Open Adobe InDesign.
2. Go to `File > Scripts > Other Script...`.
3. Select `src/build_handbook_fixed.jsx`.
4. Choose the top-level `fcvv-publishing-engine-milestone-1-fixed` folder when prompted.
5. The script saves output to `/exports`.
