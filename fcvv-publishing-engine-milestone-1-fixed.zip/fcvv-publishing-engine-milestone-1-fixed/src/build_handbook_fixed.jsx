#target "InDesign"

/*
FCVV Publishing Engine - Milestone 1 FIXED
Fixes Error Number 2 at JSON.parse(raw) by using a robust parser.
*/

function readText(path) {
    var f = new File(path);
    if (!f.exists) {
        alert("Missing file:\n" + path);
        return null;
    }
    f.encoding = "UTF-8";
    f.open("r");
    var t = f.read();
    f.close();
    return t;
}

function trimJSONText(t) {
    if (!t) return "";
    // Remove UTF-8 BOM if present.
    if (t.charCodeAt(0) === 0xFEFF) {
        t = t.substring(1);
    }
    // Basic trim for older ExtendScript engines.
    t = t.replace(/^\s+/, "").replace(/\s+$/, "");
    return t;
}

function parseJSONSafe(raw) {
    raw = trimJSONText(raw);

    // Some InDesign ExtendScript engines support JSON.parse, others do not.
    if (typeof JSON !== "undefined" && JSON.parse) {
        try {
            return JSON.parse(raw);
        } catch (e) {
            alert("JSON.parse failed. Falling back to ExtendScript eval.\n\n" + e);
        }
    }

    // Fallback for ExtendScript.
    // This is safe here because the JSON file is local project content supplied by the user.
    try {
        return eval("(" + raw + ")");
    } catch (e2) {
        alert("Could not parse content/handbook.json.\n\n" +
              "Error: " + e2 + "\n\n" +
              "First 250 characters:\n" + raw.substring(0, 250));
        return null;
    }
}

function mm(v) {
    return v + "mm";
}

function addText(page, x, y, w, h, txt, style) {
    var tf = page.textFrames.add();
    tf.geometricBounds = [mm(y), mm(x), mm(y+h), mm(x+w)];
    tf.contents = txt;
    if (style) {
        try {
            tf.parentStory.paragraphs[0].appliedParagraphStyle = app.activeDocument.paragraphStyles.itemByName(style);
        } catch(e) {}
    }
    return tf;
}

function addBox(page, x, y, w, h, fill) {
    var r = page.rectangles.add();
    r.geometricBounds = [mm(y), mm(x), mm(y+h), mm(x+w)];
    try { r.fillColor = app.activeDocument.swatches.itemByName(fill); } catch(e) {}
    try { r.strokeColor = app.activeDocument.swatches.itemByName(fill); } catch(e) {}
    return r;
}

function makeSwatch(doc, name, cmyk) {
    var s;
    try {
        s = doc.colors.itemByName(name);
        s.name;
    } catch(e) {
        s = doc.colors.add();
        s.name = name;
        s.model = ColorModel.PROCESS;
        s.space = ColorSpace.CMYK;
        s.colorValue = cmyk;
    }
    return s;
}

function makeParaStyle(doc, name, size, swatch) {
    var s;
    try {
        s = doc.paragraphStyles.itemByName(name);
        s.name;
    } catch(e) {
        s = doc.paragraphStyles.add({name:name});
    }
    s.pointSize = size;
    s.leading = size * 1.2;
    try { s.fillColor = doc.swatches.itemByName(swatch); } catch(e) {}
    return s;
}

function createStarterHandbook(data, projectFolder) {
    var doc = app.documents.add();

    doc.documentPreferences.pageWidth = "297mm";
    doc.documentPreferences.pageHeight = "210mm";
    doc.documentPreferences.facingPages = false;
    doc.documentPreferences.documentBleedTopOffset = "3mm";
    doc.documentPreferences.documentBleedBottomOffset = "3mm";
    doc.documentPreferences.documentBleedInsideOrLeftOffset = "3mm";
    doc.documentPreferences.documentBleedOutsideOrRightOffset = "3mm";

    makeSwatch(doc, "FCVV Red", [16,100,91,7]);
    makeSwatch(doc, "Midnight Black", [0,0,0,93]);
    makeSwatch(doc, "Arctic White", [0,0,0,0]);
    makeSwatch(doc, "Steel Grey", [0,0,0,15]);
    makeSwatch(doc, "Graphite", [0,0,0,60]);
    makeSwatch(doc, "Performance Green", [63,8,100,32]);
    makeSwatch(doc, "Warning Amber", [0,25,85,2]);
    makeSwatch(doc, "Coach Blue", [83,54,0,0]);

    makeParaStyle(doc, "H1_Cover", 34, "Arctic White");
    makeParaStyle(doc, "H1_Week", 26, "FCVV Red");
    makeParaStyle(doc, "H2_Section", 18, "Midnight Black");
    makeParaStyle(doc, "Body", 10.5, "Midnight Black");
    makeParaStyle(doc, "Small", 8, "Graphite");
    makeParaStyle(doc, "Quote", 14, "Graphite");

    // Cover
    var p = doc.pages[0];
    addBox(p, 0, 0, 297, 210, "Midnight Black");
    addBox(p, 0, 176, 297, 12, "FCVV Red");
    addText(p, 22, 42, 250, 18, data.publication.title, "H1_Cover");
    addText(p, 22, 70, 250, 14, data.publication.subtitle, "H1_Cover");
    addText(p, 22, 100, 250, 15, data.publication.volume, "Quote");
    addText(p, 22, 150, 250, 12, data.publication.tagline, "Quote");

    // Contents
    p = doc.pages.add();
    addText(p, 18, 18, 260, 12, "Contents", "H1_Week");
    addText(p, 20, 42, 250, 120,
        "1. How to Use This Handbook\r2. FCVV Coaching DNA\r3. Week 1 - Reconnect & Rebuild\r4. Performance Cards\r5. Coach Resources",
        "Body"
    );

    // Front Matter
    for (var i = 0; i < data.frontMatter.length; i++) {
        var fm = data.frontMatter[i];
        p = doc.pages.add();
        addText(p, 18, 18, 260, 12, fm.title, "H1_Week");
        var body = "";
        for (var j = 0; j < fm.body.length; j++) {
            body += fm.body[j] + "\r\r";
        }
        addText(p, 20, 45, 250, 120, body, "Body");
    }

    // Weeks
    for (var w = 0; w < data.weeks.length; w++) {
        var week = data.weeks[w];

        p = doc.pages.add();
        addBox(p, 0, 0, 297, 24, "Midnight Black");
        addText(p, 18, 8, 260, 12, "Week " + week.week + " - " + week.title, "H1_Cover");
        addText(p, 20, 38, 250, 20, week.statement, "Quote");

        var snap = "SESSION SNAPSHOT\r";
        for (var k in week.snapshot) {
            snap += k + ": " + week.snapshot[k] + "\r";
        }
        addText(p, 20, 68, 120, 90, snap, "Body");

        var cr = "COACH READY\rToday's Message: " + week.coachReady.message + "\r\rSuccess Looks Like:\r";
        for (var a = 0; a < week.coachReady.successLooksLike.length; a++) {
            cr += "- " + week.coachReady.successLooksLike[a] + "\r";
        }
        cr += "\rWatch For:\r";
        for (var q = 0; q < week.coachReady.watchFor.length; q++) {
            cr += "- " + week.coachReady.watchFor[q] + "\r";
        }
        addText(p, 155, 68, 120, 90, cr, "Body");

        var tl = "SESSION TIMELINE\r";
        for (var t = 0; t < week.timeline.length; t++) {
            tl += week.timeline[t][0] + "  " + week.timeline[t][1] + "\r";
        }
        addText(p, 20, 165, 250, 28, tl, "Small");

        for (var pr = 0; pr < week.practices.length; pr++) {
            var practice = week.practices[pr];

            p = doc.pages.add();
            addText(p, 18, 14, 260, 10, practice.title, "H1_Week");

            addBox(p, 18, 34, 160, 110, "Steel Grey");
            addText(p, 28, 80, 140, 20, "UEFA DIAGRAM PLACEHOLDER", "H2_Section");

            var txt = "OBJECTIVE\r" + practice.objective + "\r\rORGANISATION\r" + practice.organisation + "\r\rCOACHING POINTS\r";
            for (var cp = 0; cp < practice.coachingPoints.length; cp++) {
                txt += "- " + practice.coachingPoints[cp] + "\r";
            }
            addText(p, 188, 34, 90, 100, txt, "Body");

            addBox(p, 18, 152, 80, 34, "Performance Green");
            addText(p, 22, 158, 72, 22, "ON THE GRASS\r" + practice.onTheGrass, "Small");

            addBox(p, 108, 152, 80, 34, "Warning Amber");
            addText(p, 112, 158, 72, 22, "QUICK FIX\r" + practice.quickFix, "Small");

            addBox(p, 198, 152, 80, 34, "Steel Grey");
            addText(p, 202, 158, 72, 22, "MATCH TRANSFER\r" + practice.matchTransfer, "Small");
        }
    }

    var exportFolder = new Folder(projectFolder.fsName + "/exports");
    if (!exportFolder.exists) exportFolder.create();

    var inddFile = new File(exportFolder.fsName + "/FCVV_Handbook_Milestone1_FIXED.indd");
    doc.save(inddFile);

    try {
        var pdfFile = new File(exportFolder.fsName + "/FCVV_Handbook_Milestone1_FIXED.pdf");
        doc.exportFile(ExportFormat.PDF_TYPE, pdfFile);
    } catch(e) {
        alert("InDesign document was created, but PDF export failed:\n" + e);
    }

    alert("FCVV handbook milestone created successfully.\n\nSaved in:\n" + exportFolder.fsName);
}

var folder = Folder.selectDialog("Select the fcvv-publishing-engine-milestone-1-fixed project folder");
if (folder) {
    var raw = readText(folder.fsName + "/content/handbook.json");
    if (raw) {
        var data = parseJSONSafe(raw);
        if (data) {
            createStarterHandbook(data, folder);
        }
    }
}
