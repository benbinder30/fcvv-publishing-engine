# InDesign Setup

Run `src/build_handbook_fixed.jsx`.

This fixed script is designed to avoid JSON parsing errors in ExtendScript.
